﻿Imports System.Data
Imports System.Management

Public Class Form1

    Private Property objWMIService As Object

    Private Sub Go_Click(sender As Object, e As EventArgs) Handles Go.Click
        txt_info.Text = Get_Username(txt_pcinfo.Text)
    End Sub


    Private Function Get_Username(strComputer)
        Dim GetCurrentUser, strUserName, strUserDomain As String

        On Error Resume Next
        Dim objWMIService = GetObject("winmgmts:" & "{impersonationLevel=impersonate}!\\" & strComputer & "\root\cimv2")
        Dim colProcessList = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'explorer.exe'")
        For Each objProcess In colProcessList
            objProcess.GetOwner(strUserName, strUserDomain)
        Next
        GetCurrentUser = strUserDomain & "\" & strUserName

        On Error GoTo 0

        Return GetCurrentUser
    End Function


    Function GetUserName() As String
        If TypeOf My.User.CurrentPrincipal Is 
          Security.Principal.WindowsPrincipal Then
            ' The application is using Windows authentication.
            ' The name format is DOMAIN\USERNAME.
            Dim parts() As String = Split(My.User.Name, "\")
            Dim username As String = parts(1)
            Return username
        Else
            ' The application is using custom authentication.
            Return My.User.Name
        End If
    End Function
    Function GetUserDomain() As String
        If TypeOf My.User.CurrentPrincipal Is 
          Security.Principal.WindowsPrincipal Then
            ' My.User is using Windows authentication.
            ' The name format is DOMAIN\USERNAME.
            Dim parts() As String = Split(My.User.Name, "\")
            Dim domain As String = parts(0)
            Return domain
        Else
            ' My.User is using custom authentication.
            Return ""
        End If
    End Function




End Class


'Dim My_computername As String = System.Net.Dns.GetHostName

'wmic /NODE:"BCBBS123123" computersystem get Username
'x = System.Net.Dns.GetHostByName("localhost").HostName
'userx = My.User.Name