﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txt_pcinfo = New System.Windows.Forms.TextBox()
        Me.Go = New System.Windows.Forms.Button()
        Me.txt_info = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txt_pcinfo
        '
        Me.txt_pcinfo.Location = New System.Drawing.Point(12, 32)
        Me.txt_pcinfo.Name = "txt_pcinfo"
        Me.txt_pcinfo.Size = New System.Drawing.Size(161, 20)
        Me.txt_pcinfo.TabIndex = 0
        Me.txt_pcinfo.Text = "BCBBS167D01"
        '
        'Go
        '
        Me.Go.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Go.Location = New System.Drawing.Point(98, 84)
        Me.Go.Name = "Go"
        Me.Go.Size = New System.Drawing.Size(75, 23)
        Me.Go.TabIndex = 1
        Me.Go.Text = "Go"
        Me.Go.UseVisualStyleBackColor = True
        '
        'txt_info
        '
        Me.txt_info.Location = New System.Drawing.Point(12, 58)
        Me.txt_info.Name = "txt_info"
        Me.txt_info.ReadOnly = True
        Me.txt_info.Size = New System.Drawing.Size(161, 20)
        Me.txt_info.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(195, 131)
        Me.Controls.Add(Me.txt_info)
        Me.Controls.Add(Me.Go)
        Me.Controls.Add(Me.txt_pcinfo)
        Me.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PC Login Info"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt_pcinfo As System.Windows.Forms.TextBox
    Friend WithEvents Go As System.Windows.Forms.Button
    Friend WithEvents txt_info As System.Windows.Forms.TextBox

End Class
